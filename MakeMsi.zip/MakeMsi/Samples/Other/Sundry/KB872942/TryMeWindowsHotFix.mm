;----------------------------------------------------------------------------
;    MODULE NAME:   TryMeWindowsHotFix.MM
;
;        $Author:   USER "Dennis"  $
;      $Revision:   1.3  $
;          $Date:   21 Dec 2006 17:54:02  $
;       $Logfile:   C:/DBAREIS/Projects.PVCS/Win32/MakeMsi/TryMeWindowsHotFix.mm.pvcs  $
;
;  For this example I decided to create a common ".MMH" and ".VER" file so
;  in "real life", there would only be the ".mm" and ".exe" in the source
;  directory and each hotfix (product) would just have a different guid
;  assigned in the script (note it would be possible to also have MAKEMSI
; automatically do a once off assignment).
;----------------------------------------------------------------------------

;--- For the purposes of this example I put "common files" elsewhere, normally you'd set this up globally (not in script) ---
#evaluate ^^ ^call IncludePath 'COMMON FILES'^          ;;Example only, this is not the correct place for this code...


;--- Specify upgrade code and generate HOTFIX package -----------------------
#define  HotFix4WinXpSp2_UpgradeCode    {58418121-FB16-4C99-AB64-410343E20C2F}
#include "HotFix4WinXpSp2.MMH"
;#include "HOTFIX.MMH"                  ;;We won't call directly but via WINXP SP2 config file...

