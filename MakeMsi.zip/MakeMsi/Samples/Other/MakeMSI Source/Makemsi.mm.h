;----------------------------------------------------------------------------
;
;    MODULE NAME:   MAKEMSI.MM.H
;
;        $Author:   USER "Dennis"  $
;      $Revision:   1.7  $
;          $Date:   23 Aug 2008 14:19:50  $
;       $Logfile:   C:/DBAREIS/Projects.PVCS/Win32/MakeMsi/Makemsi.mm.h.pvcs  $
;      COPYRIGHT:   (C)opyright Dennis Bareis, Australia, 2003
;                   All rights reserved.
;
; DESCRIPTION
; ~~~~~~~~~~~
; I had to get a bit creative with the filename as I have many files with
; similar names!
;
; This file is a common header file included by MAKEMSI.MM and other
; related build scripts.
;
; It supplies some common definitions as well as loading MAKEMSI support.
;----------------------------------------------------------------------------

;--- Don't want to do this... ----------------------------------------------
#define COMMONFRAMEWORK_ZIP_SOURCE_FOR_BACKUP N

;----------------------------------------------------------------------------
;--- Apply most department/company standards and include "MAKEMSI" support --
;----------------------------------------------------------------------------
#define? DEPT_ARP_URL_PUBLISHER                 <?PpwizardAuthorHomePage>
#define? DEPT_ARP_URL_TECHNICAL_SUPPORT         <$MAKEMSI_HOMEPAGE>
#define  COMPILE_CABDDF_CompressionType         <$COMPRESS_BEST>
#define  COMPANY_HTMLRPT_DOCO_INSTALL_DIR_KEY   INSTALLDIR
#define+ MmMODE                                 P        ;;Always want to build in production mode!
#include "DENNIS.MMH"                           ;;Include MAKEMSI support (customised for me)
#define+ DEFAULT_ROW_VALIDATE_NO_WHERE          NEW

;----------------------------------------------------------------------------
;--- MAKEMSI Program IDs ----------------------------------------------------
;----------------------------------------------------------------------------
#define PROGID_MAKEMSI_MM  MAKEMSI Script Source
#define PROGID_MAKEMSI_MMH MAKEMSI Script Header

;----------------------------------------------------------------------------
;--- Windows Installer database types (HKCR) --------------------------------
;----------------------------------------------------------------------------
#(
    #define PROGIDS_MSI
    Msi.Package                     ;;MSI (one of the few MS got right)
#)
#(
    #define PROGIDS_MSM
    ;--- Merge Modules (lots of aliases - Thanks again MS) ------------------
    .msm                            ;;Native state (as Windows installs)
    Msi.MergeModule                 ;;When Orca installed
    MaSaIModule.Document            ;;When MaSaI Editor installed
    WiseModule.Document             ;;When Wise Installer PRO Installed
#)
#(
    ;--- Orca edits these file types ----------------------------------------
    #define MSI_DATABASE_TYPES

    <$PROGIDS_MSI>
    <$PROGIDS_MSM>
    .pcp                            ;;Windows Installer Patch Creation File
    .cub                            ;;Validation Database
#)
#(
    #define MSI_TRANSFORM_TYPES

    ;--- TRANSFORMS ---------------------------------------------------------
    .mst                            ;;Native state (as Windows installs)
    MaSaITransform.Document         ;;When MaSaI Editor installed
    WiseTransform.Document          ;;When Wise Installer PRO Installed
    Msi.Transform                   ;;When "InstEd" (MSI Editor) is installed
#)
#(
    #define MSI_PATCH_TYPES

    ;--- PATCHES ------------------------------------------------------------
    Msi.Patch                       ;;Standard Windows Installer progtype
#)
; .MSP => Msi.Patch


;----------------------------------------------------------------------------
;--- MSIDIFF.VBS Extensions -------------------------------------------------
;----------------------------------------------------------------------------
#define MSIDUMP_OUTPUT_DIFFERENCE     MmDiffTxt
#define MSIDUMP_OUTPUT_COMPLETE       MmDumpTxt


;----------------------------------------------------------------------------
;--- Find "WSCRIPT.EXE" (see Dennis.MMH) ------------------------------------
;----------------------------------------------------------------------------
<$CSCRIPT.EXE>
<$WSCRIPT.EXE>



;----------------------------------------------------------------------------
;--- Handy macro to create a component for each file passed -----------------
;----------------------------------------------------------------------------
#(
   #define CompPerFile
   #evaluate+ ^COMPONENT_NAME^ ^FilePart('n', '{$#1}')^
   <$Component "<$COMPONENT_NAME>" Create="Y" Directory_="{$Dir=^INSTALLDIR^}">
       <$File Source="{$#1}" Comment=~{$Comment=^^}~ KeyPath="Y">
   <$/Component>
#)

;----------------------------------------------------------------------------
;--- Handy macro to find text editor ----------------------------------------
;----------------------------------------------------------------------------
#(
   #define FIND_DEFAULT_TEXT_EDITOR_CMDLINE
   <$RegistryRead
       Property="DEFAULT_TEXT_EDITOR_CMDLINE"
        Default=^notepad.exe "%1"^
           HKEY="CLASSES_ROOT"
            Key="txtfile\shell\open\command"    ;;Probably still notepad...
   >
#)



;----------------------------------------------------------------------------
;--- Include this header file as source in the generated HTML doco ----------
;----------------------------------------------------------------------------
<$SourceForReport>

